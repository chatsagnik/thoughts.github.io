# hugo-PaperModX Example

This repository offers an example site for [hugo-PaperModX](https://github.com/reorx/hugo-PaperModX)
