---
title: My Newsletter
subtitle: What do you want to write?
description: |
  This is the template for creating a newsletter in PaperModX.
type: newsletter
cascade:
  - _target:
      kind: page
    type: newsletter
    titlePrefix: "My Newsletter: "
    newsletterName: "My Newsletter"
---
